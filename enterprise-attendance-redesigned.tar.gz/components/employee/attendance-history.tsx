'use client';

import { motion } from 'framer-motion';
import { History, Clock, Calendar, CheckCircle2, AlertCircle, XCircle, MinusCircle } from 'lucide-react';
import { format } from 'date-fns';
import useSWR from 'swr';
import { cn } from '@/lib/utils';
import { AttendanceRecord } from '@/types';

const fetcher = (url: string) => fetch(url).then(res => res.json());

const statusConfig = {
  present: {
    icon: CheckCircle2,
    color: 'text-success',
    bg: 'bg-success/10',
    label: 'Present',
  },
  late: {
    icon: AlertCircle,
    color: 'text-warning',
    bg: 'bg-warning/10',
    label: 'Late',
  },
  absent: {
    icon: XCircle,
    color: 'text-destructive',
    bg: 'bg-destructive/10',
    label: 'Absent',
  },
  'half-day': {
    icon: MinusCircle,
    color: 'text-accent',
    bg: 'bg-accent/10',
    label: 'Half Day',
  },
};

export function AttendanceHistory() {
  const { data, isLoading } = useSWR('/api/attendance/history', fetcher);

  const history: AttendanceRecord[] = data?.data?.history || [];
  const summary = data?.data?.summary;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 }}
      className="bg-card rounded-2xl border border-border shadow-lg overflow-hidden"
    >
      {/* Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
              <History className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground">Attendance History</h3>
              <p className="text-sm text-muted-foreground">
                {format(new Date(), 'MMMM yyyy')}
              </p>
            </div>
          </div>
        </div>

        {/* Summary Stats */}
        {summary && (
          <div className="grid grid-cols-4 gap-3 mt-4">
            <SummaryBadge label="Present" value={summary.present} status="present" />
            <SummaryBadge label="Late" value={summary.late} status="late" />
            <SummaryBadge label="Absent" value={summary.absent} status="absent" />
            <SummaryBadge label="Half" value={summary.halfDay} status="half-day" />
          </div>
        )}
      </div>

      {/* History List */}
      <div className="max-h-[400px] overflow-y-auto">
        {isLoading ? (
          <div className="p-6 space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="animate-pulse h-16 bg-muted rounded-xl" />
            ))}
          </div>
        ) : history.length === 0 ? (
          <div className="p-12 text-center">
            <Calendar className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
            <p className="text-muted-foreground">No attendance records yet</p>
          </div>
        ) : (
          <div className="divide-y divide-border">
            {history.slice(0, 10).map((record, index) => (
              <HistoryItem key={record.date} record={record} index={index} />
            ))}
          </div>
        )}
      </div>
    </motion.div>
  );
}

interface SummaryBadgeProps {
  label: string;
  value: number;
  status: AttendanceRecord['status'];
}

function SummaryBadge({ label, value, status }: SummaryBadgeProps) {
  const config = statusConfig[status];
  
  return (
    <div className={cn("rounded-xl p-3 text-center", config.bg)}>
      <p className={cn("text-2xl font-bold", config.color)}>{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  );
}

interface HistoryItemProps {
  record: AttendanceRecord;
  index: number;
}

function HistoryItem({ record, index }: HistoryItemProps) {
  const config = statusConfig[record.status];
  const StatusIcon = config.icon;

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.05 }}
      className="flex items-center justify-between p-4 hover:bg-muted/50 transition-colors"
    >
      <div className="flex items-center gap-4">
        <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center", config.bg)}>
          <StatusIcon className={cn("w-5 h-5", config.color)} />
        </div>
        <div>
          <p className="font-medium text-foreground">
            {format(new Date(record.date), 'EEEE')}
          </p>
          <p className="text-sm text-muted-foreground">
            {format(new Date(record.date), 'MMM d, yyyy')}
          </p>
        </div>
      </div>

      <div className="text-right">
        <div className="flex items-center gap-2 text-sm">
          <Clock className="w-4 h-4 text-muted-foreground" />
          <span className="text-foreground font-medium">
            {record.timeIn || '--:--'}
          </span>
          <span className="text-muted-foreground">-</span>
          <span className="text-foreground font-medium">
            {record.timeOut || '--:--'}
          </span>
        </div>
        {record.duration && (
          <p className="text-xs text-muted-foreground mt-1">{record.duration}</p>
        )}
      </div>
    </motion.div>
  );
}
