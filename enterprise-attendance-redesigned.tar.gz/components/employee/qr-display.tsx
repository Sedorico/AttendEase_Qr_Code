'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { QR_REFRESH_INTERVAL } from '@/lib/constants';
import { Loader2, RefreshCw, Shield, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

interface QRCodeDisplayProps {
  className?: string;
}

export function QRCodeDisplay({ className }: QRCodeDisplayProps) {
  const [qrImage, setQrImage] = useState<string | null>(null);
  const [expiresAt, setExpiresAt] = useState<number>(0);
  const [timeLeft, setTimeLeft] = useState<number>(30);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const generateQR = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/qr/generate');
      const data = await response.json();

      if (data.success && data.data) {
        setQrImage(data.data.qrImage);
        setExpiresAt(data.data.expiresAt);
      } else {
        setError(data.error || 'Failed to generate QR code');
      }
    } catch {
      setError('Network error. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Generate QR on mount and set up refresh interval
  useEffect(() => {
    generateQR();

    const interval = setInterval(() => {
      generateQR();
    }, QR_REFRESH_INTERVAL);

    return () => clearInterval(interval);
  }, [generateQR]);

  // Update countdown timer
  useEffect(() => {
    const timer = setInterval(() => {
      if (expiresAt) {
        const remaining = Math.max(0, Math.floor((expiresAt - Date.now()) / 1000));
        setTimeLeft(remaining);
      }
    }, 100);

    return () => clearInterval(timer);
  }, [expiresAt]);

  const progressPercentage = (timeLeft / 30) * 100;

  return (
    <div className={cn('flex flex-col items-center', className)}>
      {/* QR Container */}
      <div className="relative">
        {/* Outer glow ring */}
        <div 
          className="absolute -inset-4 rounded-3xl opacity-20 blur-xl transition-all duration-300"
          style={{
            background: `conic-gradient(from 0deg, var(--primary) ${progressPercentage}%, transparent ${progressPercentage}%)`,
          }}
        />
        
        {/* Progress ring */}
        <svg 
          className="absolute -inset-3 w-[calc(100%+24px)] h-[calc(100%+24px)]"
          viewBox="0 0 100 100"
        >
          <circle
            cx="50"
            cy="50"
            r="48"
            fill="none"
            stroke="currentColor"
            strokeWidth="1"
            className="text-border"
          />
          <circle
            cx="50"
            cy="50"
            r="48"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            className="text-primary transition-all duration-100"
            strokeDasharray={`${progressPercentage * 3.02} 302`}
            transform="rotate(-90 50 50)"
          />
        </svg>

        {/* QR Code Card */}
        <motion.div 
          className="relative bg-card rounded-2xl p-4 shadow-2xl border border-border"
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          <AnimatePresence mode="wait">
            {isLoading ? (
              <motion.div
                key="loading"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="w-64 h-64 flex items-center justify-center"
              >
                <div className="flex flex-col items-center gap-3">
                  <Loader2 className="w-10 h-10 text-primary animate-spin" />
                  <span className="text-sm text-muted-foreground">Generating secure QR...</span>
                </div>
              </motion.div>
            ) : error ? (
              <motion.div
                key="error"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="w-64 h-64 flex items-center justify-center"
              >
                <div className="flex flex-col items-center gap-3 text-center px-4">
                  <div className="w-12 h-12 rounded-full bg-destructive/10 flex items-center justify-center">
                    <Shield className="w-6 h-6 text-destructive" />
                  </div>
                  <p className="text-sm text-destructive">{error}</p>
                  <button
                    onClick={generateQR}
                    className="flex items-center gap-2 text-sm text-primary hover:underline"
                  >
                    <RefreshCw className="w-4 h-4" />
                    Retry
                  </button>
                </div>
              </motion.div>
            ) : qrImage ? (
              <motion.div
                key="qr"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="relative"
              >
                <img
                  src={qrImage}
                  alt="Your QR Code"
                  className="w-64 h-64 rounded-lg"
                />
                {/* Scan line animation */}
                <div className="absolute inset-0 overflow-hidden rounded-lg pointer-events-none">
                  <div className="scan-line absolute left-0 right-0 h-1 bg-gradient-to-r from-transparent via-primary to-transparent opacity-60" />
                </div>
              </motion.div>
            ) : null}
          </AnimatePresence>
        </motion.div>
      </div>

      {/* Timer display */}
      <motion.div 
        className="mt-6 flex items-center gap-2 px-4 py-2 rounded-full bg-card border border-border"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        <Clock className="w-4 h-4 text-muted-foreground" />
        <span className="text-sm text-muted-foreground">Refreshes in</span>
        <span 
          className={cn(
            "font-mono font-bold text-lg tabular-nums",
            timeLeft <= 5 ? "text-destructive" : timeLeft <= 10 ? "text-warning" : "text-primary"
          )}
        >
          {timeLeft}s
        </span>
      </motion.div>

      {/* Security badge */}
      <motion.div 
        className="mt-4 flex items-center gap-2 text-xs text-muted-foreground"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        <Shield className="w-3 h-3" />
        <span>Cryptographically signed &bull; One-time use</span>
      </motion.div>
    </div>
  );
}
