'use client';

import { motion } from 'framer-motion';
import { 
  Clock, 
  LogIn, 
  LogOut, 
  CheckCircle2, 
  XCircle,
  Calendar
} from 'lucide-react';
import { format } from 'date-fns';
import useSWR from 'swr';
import { cn } from '@/lib/utils';

const fetcher = (url: string) => fetch(url).then(res => res.json());

export function TodayStatus() {
  const { data, isLoading } = useSWR('/api/attendance/today', fetcher, {
    refreshInterval: 30000, // Refresh every 30 seconds
  });

  const timeIn = data?.data?.timeIn;
  const timeOut = data?.data?.timeOut;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card rounded-2xl border border-border p-6 shadow-lg"
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <Calendar className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">Today&apos;s Status</h3>
            <p className="text-sm text-muted-foreground">
              {format(new Date(), 'EEEE, MMMM d, yyyy')}
            </p>
          </div>
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-2 gap-4">
          {[1, 2].map((i) => (
            <div key={i} className="animate-pulse">
              <div className="h-24 bg-muted rounded-xl" />
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-4">
          {/* Time In Card */}
          <TimeCard
            type="in"
            timestamp={timeIn?.timestamp}
            icon={LogIn}
          />

          {/* Time Out Card */}
          <TimeCard
            type="out"
            timestamp={timeOut?.timestamp}
            icon={LogOut}
          />
        </div>
      )}
    </motion.div>
  );
}

interface TimeCardProps {
  type: 'in' | 'out';
  timestamp?: string;
  icon: typeof LogIn;
}

function TimeCard({ type, timestamp, icon: Icon }: TimeCardProps) {
  const isComplete = !!timestamp;
  const label = type === 'in' ? 'Time In' : 'Time Out';
  
  return (
    <div 
      className={cn(
        "relative rounded-xl p-4 border transition-all duration-300",
        isComplete 
          ? "bg-success/5 border-success/20" 
          : "bg-muted/50 border-border"
      )}
    >
      {/* Status indicator */}
      <div className="absolute top-3 right-3">
        {isComplete ? (
          <CheckCircle2 className="w-5 h-5 text-success" />
        ) : (
          <XCircle className="w-5 h-5 text-muted-foreground" />
        )}
      </div>

      <div className="flex items-center gap-2 mb-3">
        <div 
          className={cn(
            "w-8 h-8 rounded-lg flex items-center justify-center",
            isComplete ? "bg-success/10" : "bg-muted"
          )}
        >
          <Icon 
            className={cn(
              "w-4 h-4",
              isComplete ? "text-success" : "text-muted-foreground"
            )} 
          />
        </div>
        <span className="text-sm font-medium text-muted-foreground">{label}</span>
      </div>

      <div className="flex items-baseline gap-1">
        {isComplete ? (
          <>
            <Clock className="w-4 h-4 text-foreground" />
            <span className="text-2xl font-bold text-foreground">
              {format(new Date(timestamp!), 'h:mm')}
            </span>
            <span className="text-sm text-muted-foreground">
              {format(new Date(timestamp!), 'a')}
            </span>
          </>
        ) : (
          <span className="text-lg text-muted-foreground">--:--</span>
        )}
      </div>
    </div>
  );
}
