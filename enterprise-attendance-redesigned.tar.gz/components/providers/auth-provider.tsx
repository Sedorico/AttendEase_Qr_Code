'use client';

import { useEffect, useState } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { useAuthStore } from '@/lib/stores';

interface AuthProviderProps {
  children: React.ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const router = useRouter();
  const pathname = usePathname();
  const { setUser, setLoading, logout, isAuthenticated } = useAuthStore();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (!mounted) return;

    const checkAuth = async () => {
      setLoading(true);
      try {
        const response = await fetch('/api/auth/me');
        const data = await response.json();

        if (data.success && data.data?.employee) {
          setUser(data.data.employee);
        } else {
          logout();
          // Redirect to login if on protected route
          if (!pathname.startsWith('/login') && 
              !pathname.startsWith('/register') && 
              !pathname.startsWith('/scanner')) {
            router.push('/login');
          }
        }
      } catch {
        logout();
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, [mounted, setUser, setLoading, logout, router, pathname]);

  useEffect(() => {
    if (!mounted) return;

    // Redirect authenticated users away from auth pages
    if (isAuthenticated && (pathname === '/login' || pathname === '/register')) {
      router.push('/employee');
    }
  }, [mounted, isAuthenticated, pathname, router]);

  if (!mounted) {
    return null;
  }

  return <>{children}</>;
}
