import mongoose, { Schema, Document, Model } from 'mongoose';

export interface IAttendance extends Document {
  employeeId: mongoose.Types.ObjectId;
  type: 'TIME_IN' | 'TIME_OUT';
  timestamp: Date;
  deviceInfo?: string;
  qrTokenUsed: string;
  location?: string;
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}

const AttendanceSchema = new Schema<IAttendance>(
  {
    employeeId: {
      type: Schema.Types.ObjectId,
      ref: 'Employee',
      required: [true, 'Employee ID is required'],
      index: true,
    },
    type: {
      type: String,
      enum: ['TIME_IN', 'TIME_OUT'],
      required: [true, 'Attendance type is required'],
    },
    timestamp: {
      type: Date,
      required: [true, 'Timestamp is required'],
      default: Date.now,
      index: true,
    },
    deviceInfo: {
      type: String,
      default: '',
    },
    qrTokenUsed: {
      type: String,
      required: [true, 'QR token is required'],
      index: true,
    },
    location: {
      type: String,
      default: '',
    },
    notes: {
      type: String,
      default: '',
    },
  },
  {
    timestamps: true,
  }
);

// Compound index for efficient queries
AttendanceSchema.index({ employeeId: 1, timestamp: -1 });
AttendanceSchema.index({ timestamp: 1, type: 1 });

// Static method to get today's attendance for an employee
AttendanceSchema.statics.getTodayAttendance = async function (employeeId: string) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);

  return this.find({
    employeeId,
    timestamp: {
      $gte: today,
      $lt: tomorrow,
    },
  }).sort({ timestamp: 1 });
};

// Static method to check if employee has already timed in/out today
AttendanceSchema.statics.hasRecordToday = async function (
  employeeId: string,
  type: 'TIME_IN' | 'TIME_OUT'
) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);

  const record = await this.findOne({
    employeeId,
    type,
    timestamp: {
      $gte: today,
      $lt: tomorrow,
    },
  });

  return !!record;
};

const Attendance: Model<IAttendance> =
  mongoose.models.Attendance || mongoose.model<IAttendance>('Attendance', AttendanceSchema);

export default Attendance;
