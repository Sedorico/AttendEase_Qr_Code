'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { 
  QrCode, Mail, Lock, Eye, EyeOff, ArrowRight, Loader2,
  User, Building2, Briefcase, CheckCircle2, Shield, Zap
} from 'lucide-react';
import { useAuthStore } from '@/lib/stores';
import { DEPARTMENTS } from '@/lib/constants';
import { cn } from '@/lib/utils';

export default function RegisterPage() {
  const router = useRouter();
  const { login } = useAuthStore();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    department: '',
    position: '',
  });
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (data.success && data.data) {
        login(data.data.employee, data.data.token);
        router.push('/employee');
      } else {
        setError(data.error || 'Registration failed');
      }
    } catch {
      setError('Network error. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex bg-background">
      {/* Left Side - Branding (Hidden on mobile) */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden">
        {/* Background - 51Talk inspired */}
        <div className="absolute inset-0 bg-gradient-to-br from-accent/20 via-accent/10 to-primary/10" />
        
        {/* Decorative circles */}
        <div className="absolute inset-0">
          <div className="absolute top-32 right-20 w-80 h-80 bg-accent/30 rounded-full blur-[100px] animate-pulse-glow" />
          <div className="absolute bottom-20 left-20 w-64 h-64 bg-primary/30 rounded-full blur-[80px] animate-pulse-glow" style={{ animationDelay: '1s' }} />
        </div>

        <div className="relative z-10 flex flex-col justify-center px-12 lg:px-16 xl:px-20 w-full">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
          >
            {/* Logo */}
            <div className="flex items-center gap-3 mb-10">
              <div className="w-14 h-14 rounded-2xl bg-accent flex items-center justify-center shadow-xl shadow-accent/30">
                <Building2 className="w-8 h-8 text-accent-foreground" />
              </div>
              <span className="text-3xl font-bold text-foreground">AttendQR</span>
            </div>

            <h1 className="text-4xl xl:text-5xl font-bold text-foreground mb-5 leading-tight">
              Join Your Team&apos;s
              <span className="block mt-1 bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">
                Attendance System
              </span>
            </h1>
            
            <p className="text-lg text-muted-foreground mb-10 max-w-lg leading-relaxed">
              Create your account and start tracking your attendance with our secure QR-based system.
            </p>

            {/* Benefits */}
            <div className="space-y-4">
              {[
                { icon: QrCode, text: 'Get your unique QR code instantly' },
                { icon: Zap, text: 'Quick and easy check-in process' },
                { icon: Shield, text: 'Your data is secure and private' },
              ].map((benefit, i) => (
                <motion.div
                  key={benefit.text}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + i * 0.15 }}
                  className="flex items-center gap-4 p-3 rounded-xl bg-card/50 backdrop-blur-sm border border-border/50"
                >
                  <div className="w-10 h-10 rounded-xl bg-success/20 flex items-center justify-center">
                    <benefit.icon className="w-5 h-5 text-success" />
                  </div>
                  <span className="text-foreground font-medium">{benefit.text}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>

      {/* Right Side - Registration Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 sm:p-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-lg"
        >
          {/* Mobile Logo */}
          <div className="lg:hidden flex items-center gap-3 mb-8 justify-center">
            <div className="w-12 h-12 rounded-2xl bg-accent flex items-center justify-center shadow-lg shadow-accent/30">
              <Building2 className="w-7 h-7 text-accent-foreground" />
            </div>
            <span className="text-2xl font-bold text-foreground">AttendQR</span>
          </div>

          {/* Card */}
          <div className="bg-card border border-border rounded-3xl shadow-xl p-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-foreground mb-2">Create Account</h2>
              <p className="text-muted-foreground">Join your organization&apos;s attendance system</p>
            </div>

            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-6 p-4 rounded-2xl bg-destructive/10 border border-destructive/20 text-destructive text-sm flex items-center gap-2"
              >
                <span className="w-5 h-5 rounded-full bg-destructive/20 flex items-center justify-center text-xs">!</span>
                {error}
              </motion.div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Name */}
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-foreground mb-2">
                  Full Name
                </label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    className={cn(
                      "w-full h-13 pl-12 pr-4 rounded-xl border-2 border-border bg-background text-foreground",
                      "focus:outline-none focus:ring-0 focus:border-accent",
                      "transition-all duration-200 placeholder:text-muted-foreground/60"
                    )}
                    placeholder="John Doe"
                    required
                  />
                </div>
              </div>

              {/* Email */}
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-foreground mb-2">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    className={cn(
                      "w-full h-13 pl-12 pr-4 rounded-xl border-2 border-border bg-background text-foreground",
                      "focus:outline-none focus:ring-0 focus:border-accent",
                      "transition-all duration-200 placeholder:text-muted-foreground/60"
                    )}
                    placeholder="john@company.com"
                    required
                  />
                </div>
              </div>

              {/* Password */}
              <div>
                <label htmlFor="password" className="block text-sm font-medium text-foreground mb-2">
                  Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <input
                    id="password"
                    name="password"
                    type={showPassword ? 'text' : 'password'}
                    value={formData.password}
                    onChange={handleChange}
                    className={cn(
                      "w-full h-13 pl-12 pr-12 rounded-xl border-2 border-border bg-background text-foreground",
                      "focus:outline-none focus:ring-0 focus:border-accent",
                      "transition-all duration-200 placeholder:text-muted-foreground/60"
                    )}
                    placeholder="Min. 6 characters"
                    minLength={6}
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {/* Department & Position Row */}
              <div className="grid grid-cols-2 gap-4">
                {/* Department */}
                <div>
                  <label htmlFor="department" className="block text-sm font-medium text-foreground mb-2">
                    Department
                  </label>
                  <div className="relative">
                    <Building2 className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground pointer-events-none" />
                    <select
                      id="department"
                      name="department"
                      value={formData.department}
                      onChange={handleChange}
                      className={cn(
                        "w-full h-13 pl-12 pr-4 rounded-xl border-2 border-border bg-background text-foreground appearance-none cursor-pointer",
                        "focus:outline-none focus:ring-0 focus:border-accent",
                        "transition-all duration-200"
                      )}
                      required
                    >
                      <option value="">Select</option>
                      {DEPARTMENTS.map(dept => (
                        <option key={dept} value={dept}>{dept}</option>
                      ))}
                    </select>
                    <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none">
                      <svg className="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                      </svg>
                    </div>
                  </div>
                </div>

                {/* Position */}
                <div>
                  <label htmlFor="position" className="block text-sm font-medium text-foreground mb-2">
                    Position
                  </label>
                  <div className="relative">
                    <Briefcase className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <input
                      id="position"
                      name="position"
                      type="text"
                      value={formData.position}
                      onChange={handleChange}
                      className={cn(
                        "w-full h-13 pl-12 pr-4 rounded-xl border-2 border-border bg-background text-foreground",
                        "focus:outline-none focus:ring-0 focus:border-accent",
                        "transition-all duration-200 placeholder:text-muted-foreground/60"
                      )}
                      placeholder="Job Title"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Submit Button - Cyan like 51Talk form */}
              <button
                type="submit"
                disabled={isLoading}
                className={cn(
                  "w-full h-13 rounded-xl font-semibold text-accent-foreground mt-2",
                  "bg-accent hover:bg-accent/90 transition-all duration-200",
                  "flex items-center justify-center gap-2",
                  "shadow-lg shadow-accent/30 hover:shadow-xl hover:shadow-accent/40",
                  "disabled:opacity-50 disabled:cursor-not-allowed"
                )}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Creating Account...
                  </>
                ) : (
                  <>
                    Create Account
                    <ArrowRight className="w-5 h-5" />
                  </>
                )}
              </button>
            </form>

            {/* Login Link */}
            <p className="mt-6 text-center text-sm text-muted-foreground">
              Already have an account?{' '}
              <Link href="/login" className="text-primary font-semibold hover:underline">
                Sign in
              </Link>
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
