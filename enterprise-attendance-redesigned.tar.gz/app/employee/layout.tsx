import { EmployeeNav } from '@/components/employee/employee-nav';

export default function EmployeeLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-background">
      <EmployeeNav />
      <main className="pb-20 md:pb-0">
        {children}
      </main>
    </div>
  );
}
