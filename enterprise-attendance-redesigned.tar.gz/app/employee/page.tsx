'use client';

import { motion } from 'framer-motion';
import { QRCodeDisplay } from '@/components/employee/qr-display';
import { TodayStatus } from '@/components/employee/today-status';
import { AttendanceHistory } from '@/components/employee/attendance-history';
import { useAuthStore } from '@/lib/stores';
import { Loader2, Sparkles, Building2, Mail, Briefcase } from 'lucide-react';

export default function EmployeeDashboard() {
  const { user, isLoading } = useAuthStore();

  if (isLoading) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-primary/20 flex items-center justify-center">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
          <p className="text-muted-foreground">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-6 md:py-10 max-w-7xl">
      {/* Welcome Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <div className="flex items-center gap-3 mb-2">
          <motion.div 
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring" }}
            className="w-12 h-12 rounded-2xl bg-primary/20 flex items-center justify-center"
          >
            <Sparkles className="w-6 h-6 text-primary" />
          </motion.div>
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-foreground">
              Welcome back, <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">{user?.name?.split(' ')[0]}</span>
            </h1>
            <p className="text-muted-foreground">
              Scan your QR code at the office kiosk to record your attendance
            </p>
          </div>
        </div>
      </motion.div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Left Column - QR Code */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="space-y-6"
        >
          {/* QR Card - Glass effect */}
          <div className="relative overflow-hidden bg-card rounded-3xl border border-border p-8 shadow-xl">
            {/* Background gradient */}
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />
            
            <div className="relative">
              <div className="text-center mb-6">
                <h2 className="text-xl font-semibold text-foreground mb-1">Your Dynamic QR Code</h2>
                <p className="text-sm text-muted-foreground">
                  Show this to the scanner kiosk
                </p>
              </div>
              <QRCodeDisplay />
            </div>
          </div>

          {/* Employee Info Card - Modern design */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-card rounded-3xl border border-border p-6 shadow-xl overflow-hidden relative"
          >
            {/* Background accent */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-full blur-3xl" />
            
            <div className="relative flex items-center gap-5">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center shadow-lg">
                <span className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                  {user?.name?.charAt(0).toUpperCase()}
                </span>
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-lg text-foreground">{user?.name}</h3>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Briefcase className="w-4 h-4" />
                  <span>{user?.position}</span>
                </div>
              </div>
              <div className="text-right">
                <p className="text-xs text-muted-foreground mb-1">Employee ID</p>
                <p className="font-mono text-sm font-semibold text-foreground bg-muted px-3 py-1 rounded-lg">{user?.employeeId}</p>
              </div>
            </div>
            
            <div className="relative mt-5 pt-5 border-t border-border grid grid-cols-2 gap-4">
              <div className="flex items-center gap-2 text-sm">
                <Building2 className="w-4 h-4 text-muted-foreground" />
                <span className="text-muted-foreground">{user?.department}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Mail className="w-4 h-4 text-muted-foreground" />
                <span className="text-muted-foreground truncate">{user?.email}</span>
              </div>
            </div>
          </motion.div>
        </motion.div>

        {/* Right Column - Status & History */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-6"
        >
          <TodayStatus />
          <AttendanceHistory />
        </motion.div>
      </div>
    </div>
  );
}
