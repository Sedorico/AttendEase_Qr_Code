'use client';

import { motion } from 'framer-motion';
import { AttendanceHistory } from '@/components/employee/attendance-history';
import { History, Calendar, TrendingUp } from 'lucide-react';

export default function HistoryPage() {
  return (
    <div className="container mx-auto px-4 py-6 md:py-10 max-w-4xl">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <div className="flex items-center gap-4 mb-3">
          <motion.div 
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring" }}
            className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center shadow-lg"
          >
            <History className="w-7 h-7 text-primary" />
          </motion.div>
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-foreground">
              Attendance History
            </h1>
            <p className="text-muted-foreground">
              View your complete attendance records and statistics
            </p>
          </div>
        </div>
      </motion.div>

      {/* Quick Stats */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-2 gap-4 mb-8"
      >
        <div className="bg-card rounded-2xl border border-border p-5 shadow-lg">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-success/10 flex items-center justify-center">
              <Calendar className="w-5 h-5 text-success" />
            </div>
            <span className="text-sm font-medium text-muted-foreground">This Month</span>
          </div>
          <p className="text-3xl font-bold text-foreground">--</p>
          <p className="text-xs text-muted-foreground">Days Present</p>
        </div>
        <div className="bg-card rounded-2xl border border-border p-5 shadow-lg">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-primary" />
            </div>
            <span className="text-sm font-medium text-muted-foreground">Attendance Rate</span>
          </div>
          <p className="text-3xl font-bold text-foreground">--%</p>
          <p className="text-xs text-muted-foreground">Overall Rate</p>
        </div>
      </motion.div>

      {/* History Component */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <AttendanceHistory />
      </motion.div>
    </div>
  );
}
