'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { Html5Qrcode, Html5QrcodeScannerState } from 'html5-qrcode';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  QrCode, 
  Camera, 
  CameraOff, 
  Volume2, 
  VolumeX,
  Maximize,
  CheckCircle2,
  XCircle,
  Clock,
  User,
  Building2,
  RefreshCw,
  AlertTriangle
} from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

interface ScanResult {
  success: boolean;
  employee?: {
    name: string;
    employeeId: string;
    department: string;
    position: string;
  };
  type?: 'TIME_IN' | 'TIME_OUT';
  timestamp?: string;
  isLate?: boolean;
  error?: string;
}

export default function ScannerPage() {
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [recentScans, setRecentScans] = useState<ScanResult[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const lastScanRef = useRef<number>(0);

  // Update current time
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Play sound
  const playSound = useCallback((type: 'success' | 'error') => {
    if (!soundEnabled) return;
    
    const audio = new Audio(type === 'success' 
      ? 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdH2IkI+Nh4aBhICEh4yRlZeWlJGNiYWBgICAg4eKjo+QjoyJhoSCgYGChYiLjY+PjoyKh4WDgoGBgoWHio2PkJCOjImGhIKBgYKEh4qNj5CQjo2KhoSDgoGChIeKjI6QkI6MiYaEgoGBgoSHioyOkJCOjImHhYOBgYKEh4qMjo+Pjo2Kh4WDgoGBgoSHioyOj4+OjYqHhYOCgYGChIeKjI6Pj46NioeFg4KBgYKEh4qMjo+Pjo2Kh4WDgoGBgoSHioyOj4+OjYqHhYOCgYGChIeKjI6Pj46NioeFg4KBgQ=='
      : 'data:audio/wav;base64,UklGRl9vAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YTtvAAAAAGBmfH2DhoiIiIeGhYOBgH9/f4CChIaIiYmIh4WDgX9+fn+Ag4WHiYqKiYeGhIJ/fn5/gIOGiImKiomHhYOBf35+f4CDhoiKi4qJh4WDgX9+fn+Ag4aIiouKiYeFg4F/fn5/gIOGiIqLiomHhYOBf35+f4CDhoiKi4qJh4WDgX9+fn+Ag4aIiouKiYeFg4F/fn5/gIOGiIqLiomHhYOBf35+fw=='
    );
    audio.play().catch(() => {});
  }, [soundEnabled]);

  // Process QR scan
  const processQRCode = useCallback(async (qrData: string) => {
    // Prevent duplicate scans within 3 seconds
    const now = Date.now();
    if (now - lastScanRef.current < 3000) return;
    lastScanRef.current = now;

    setIsProcessing(true);

    try {
      const response = await fetch('/api/qr/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          qrData,
          deviceInfo: 'Scanner Kiosk'
        }),
      });

      const data = await response.json();

      const result: ScanResult = {
        success: data.success,
        employee: data.data?.employee,
        type: data.data?.type,
        timestamp: data.data?.timestamp,
        isLate: data.data?.isLate,
        error: data.error,
      };

      setScanResult(result);
      playSound(result.success ? 'success' : 'error');

      if (result.success) {
        setRecentScans(prev => [result, ...prev].slice(0, 5));
      }

      // Auto-clear result after 5 seconds
      setTimeout(() => {
        setScanResult(null);
      }, 5000);
    } catch {
      const result: ScanResult = {
        success: false,
        error: 'Network error. Please try again.',
      };
      setScanResult(result);
      playSound('error');
    } finally {
      setIsProcessing(false);
    }
  }, [playSound]);

  // Start scanner
  const startScanner = useCallback(async () => {
    if (scannerRef.current) {
      const state = scannerRef.current.getState();
      if (state === Html5QrcodeScannerState.SCANNING) {
        return;
      }
    }

    try {
      const html5QrCode = new Html5Qrcode('qr-reader');
      scannerRef.current = html5QrCode;

      await html5QrCode.start(
        { facingMode: 'environment' },
        {
          fps: 10,
          qrbox: { width: 300, height: 300 },
        },
        (decodedText) => {
          processQRCode(decodedText);
        },
        () => {}
      );

      setIsScanning(true);
    } catch (error) {
      console.error('Scanner error:', error);
    }
  }, [processQRCode]);

  // Stop scanner
  const stopScanner = useCallback(async () => {
    if (scannerRef.current) {
      try {
        await scannerRef.current.stop();
        scannerRef.current = null;
      } catch {
        // Ignore cleanup errors
      }
    }
    setIsScanning(false);
  }, []);

  // Toggle fullscreen
  const toggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopScanner();
    };
  }, [stopScanner]);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="bg-card border-b border-border px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary flex items-center justify-center">
              <QrCode className="w-7 h-7 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground">AttendEase Scanner</h1>
              <p className="text-sm text-muted-foreground">Office Kiosk Mode</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {/* Current Time */}
            <div className="text-right">
              <p className="text-3xl font-bold font-mono text-foreground">
                {format(currentTime, 'HH:mm:ss')}
              </p>
              <p className="text-sm text-muted-foreground">
                {format(currentTime, 'EEEE, MMMM d, yyyy')}
              </p>
            </div>

            {/* Controls */}
            <div className="flex items-center gap-2 pl-4 border-l border-border">
              <button
                onClick={() => setSoundEnabled(!soundEnabled)}
                className={cn(
                  "w-10 h-10 rounded-lg flex items-center justify-center transition-colors",
                  soundEnabled ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"
                )}
              >
                {soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
              </button>
              <button
                onClick={toggleFullscreen}
                className="w-10 h-10 rounded-lg flex items-center justify-center bg-muted text-muted-foreground hover:text-foreground transition-colors"
              >
                <Maximize className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex">
        {/* Scanner Section */}
        <div className="flex-1 flex flex-col items-center justify-center p-8">
          {/* Scanner Container */}
          <div className="relative">
            {/* Scanner Frame */}
            <div className="relative w-[400px] h-[400px] bg-card rounded-3xl border-2 border-border overflow-hidden">
              {/* QR Reader */}
              <div id="qr-reader" className="w-full h-full" />

              {/* Overlay when not scanning */}
              {!isScanning && (
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-card">
                  <Camera className="w-16 h-16 text-muted-foreground mb-4" />
                  <p className="text-muted-foreground text-center">
                    Click Start to begin scanning
                  </p>
                </div>
              )}

              {/* Scan line animation */}
              {isScanning && (
                <div className="absolute inset-0 pointer-events-none">
                  <div className="scan-line absolute left-4 right-4 h-1 bg-gradient-to-r from-transparent via-primary to-transparent opacity-80" />
                </div>
              )}

              {/* Corner decorations */}
              <div className="absolute top-4 left-4 w-8 h-8 border-t-4 border-l-4 border-primary rounded-tl-lg" />
              <div className="absolute top-4 right-4 w-8 h-8 border-t-4 border-r-4 border-primary rounded-tr-lg" />
              <div className="absolute bottom-4 left-4 w-8 h-8 border-b-4 border-l-4 border-primary rounded-bl-lg" />
              <div className="absolute bottom-4 right-4 w-8 h-8 border-b-4 border-r-4 border-primary rounded-br-lg" />
            </div>

            {/* Processing overlay */}
            {isProcessing && (
              <div className="absolute inset-0 bg-background/80 backdrop-blur-sm rounded-3xl flex items-center justify-center">
                <div className="flex flex-col items-center gap-3">
                  <RefreshCw className="w-10 h-10 text-primary animate-spin" />
                  <p className="text-foreground font-medium">Processing...</p>
                </div>
              </div>
            )}
          </div>

          {/* Scanner Controls */}
          <div className="mt-8 flex items-center gap-4">
            {isScanning ? (
              <button
                onClick={stopScanner}
                className="flex items-center gap-2 px-8 py-4 rounded-xl bg-destructive text-destructive-foreground font-semibold hover:bg-destructive/90 transition-colors"
              >
                <CameraOff className="w-5 h-5" />
                Stop Scanner
              </button>
            ) : (
              <button
                onClick={startScanner}
                className="flex items-center gap-2 px-8 py-4 rounded-xl bg-primary text-primary-foreground font-semibold hover:bg-primary/90 transition-colors"
              >
                <Camera className="w-5 h-5" />
                Start Scanner
              </button>
            )}
          </div>

          {/* Instructions */}
          <p className="mt-4 text-muted-foreground text-center max-w-md">
            Position your QR code within the frame. The scanner will automatically detect and process it.
          </p>
        </div>

        {/* Results Panel */}
        <div className="w-96 bg-card border-l border-border p-6 flex flex-col">
          {/* Current Result */}
          <div className="mb-6">
            <h2 className="text-lg font-semibold text-foreground mb-4">Scan Result</h2>
            
            <AnimatePresence mode="wait">
              {scanResult ? (
                <motion.div
                  key="result"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className={cn(
                    "rounded-2xl p-6 border-2",
                    scanResult.success 
                      ? "bg-success/10 border-success" 
                      : "bg-destructive/10 border-destructive"
                  )}
                >
                  {scanResult.success ? (
                    <>
                      {/* Success Icon */}
                      <div className="flex justify-center mb-4">
                        <div className="w-16 h-16 rounded-full bg-success/20 flex items-center justify-center">
                          <CheckCircle2 className="w-10 h-10 text-success" />
                        </div>
                      </div>

                      {/* Type Badge */}
                      <div className="flex justify-center mb-4">
                        <span className={cn(
                          "px-4 py-2 rounded-full text-sm font-bold",
                          scanResult.type === 'TIME_IN' 
                            ? "bg-success text-success-foreground" 
                            : "bg-primary text-primary-foreground"
                        )}>
                          {scanResult.type === 'TIME_IN' ? 'TIME IN' : 'TIME OUT'}
                          {scanResult.isLate && ' (Late)'}
                        </span>
                      </div>

                      {/* Employee Info */}
                      <div className="space-y-3">
                        <div className="flex items-center gap-3">
                          <User className="w-5 h-5 text-muted-foreground" />
                          <div>
                            <p className="font-bold text-foreground text-lg">
                              {scanResult.employee?.name}
                            </p>
                            <p className="text-sm text-muted-foreground font-mono">
                              {scanResult.employee?.employeeId}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Building2 className="w-5 h-5 text-muted-foreground" />
                          <div>
                            <p className="text-foreground">{scanResult.employee?.department}</p>
                            <p className="text-sm text-muted-foreground">
                              {scanResult.employee?.position}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Clock className="w-5 h-5 text-muted-foreground" />
                          <p className="text-foreground">
                            {scanResult.timestamp && format(new Date(scanResult.timestamp), 'h:mm:ss a')}
                          </p>
                        </div>
                      </div>
                    </>
                  ) : (
                    <>
                      {/* Error Icon */}
                      <div className="flex justify-center mb-4">
                        <div className="w-16 h-16 rounded-full bg-destructive/20 flex items-center justify-center">
                          <XCircle className="w-10 h-10 text-destructive" />
                        </div>
                      </div>

                      {/* Error Message */}
                      <div className="text-center">
                        <p className="font-bold text-destructive text-lg mb-2">Scan Failed</p>
                        <p className="text-muted-foreground">{scanResult.error}</p>
                      </div>
                    </>
                  )}
                </motion.div>
              ) : (
                <motion.div
                  key="waiting"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="rounded-2xl p-8 border-2 border-dashed border-border text-center"
                >
                  <QrCode className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
                  <p className="text-muted-foreground">Waiting for scan...</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Recent Scans */}
          <div className="flex-1">
            <h3 className="text-sm font-semibold text-muted-foreground mb-3">Recent Scans</h3>
            {recentScans.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                No recent scans
              </p>
            ) : (
              <div className="space-y-2">
                {recentScans.map((scan, index) => (
                  <motion.div
                    key={`${scan.employee?.employeeId}-${scan.timestamp}`}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="flex items-center gap-3 p-3 rounded-xl bg-muted/50"
                  >
                    <div className={cn(
                      "w-8 h-8 rounded-full flex items-center justify-center",
                      scan.type === 'TIME_IN' ? "bg-success/10" : "bg-primary/10"
                    )}>
                      <span className={cn(
                        "text-xs font-bold",
                        scan.type === 'TIME_IN' ? "text-success" : "text-primary"
                      )}>
                        {scan.type === 'TIME_IN' ? 'IN' : 'OUT'}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">
                        {scan.employee?.name}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {scan.timestamp && format(new Date(scan.timestamp), 'h:mm a')}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>

          {/* Warning for late */}
          {scanResult?.isLate && (
            <div className="mt-4 p-3 rounded-xl bg-warning/10 border border-warning/20 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-warning" />
              <span className="text-sm text-warning">Employee arrived late</span>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
