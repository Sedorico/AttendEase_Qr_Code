import { NextRequest, NextResponse } from 'next/server';
import connectDB from '@/lib/db';
import Employee from '@/lib/models/Employee';
import { getAuthFromCookies } from '@/lib/auth';
import { ApiResponse, Employee as EmployeeType } from '@/types';

interface Params {
  params: Promise<{ id: string }>;
}

// Get single employee
export async function GET(request: NextRequest, { params }: Params) {
  try {
    const auth = await getAuthFromCookies();

    if (!auth) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const { id } = await params;

    await connectDB();

    const employee = await Employee.findById(id);

    if (!employee) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Employee not found' },
        { status: 404 }
      );
    }

    // Non-admin can only view their own profile
    if (auth.role !== 'admin' && auth.userId !== id) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Access denied' },
        { status: 403 }
      );
    }

    return NextResponse.json<ApiResponse<{ employee: Partial<EmployeeType> }>>(
      {
        success: true,
        data: {
          employee: {
            _id: employee._id.toString(),
            employeeId: employee.employeeId,
            name: employee.name,
            email: employee.email,
            department: employee.department,
            position: employee.position,
            avatar: employee.avatar,
            role: employee.role,
            isActive: employee.isActive,
            createdAt: employee.createdAt.toISOString(),
          },
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Get employee error:', error);
    return NextResponse.json<ApiResponse>(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// Update employee
export async function PUT(request: NextRequest, { params }: Params) {
  try {
    const auth = await getAuthFromCookies();

    if (!auth) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const { id } = await params;

    // Non-admin can only update their own profile (limited fields)
    if (auth.role !== 'admin' && auth.userId !== id) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Access denied' },
        { status: 403 }
      );
    }

    await connectDB();

    const data = await request.json();

    // Non-admin cannot change role, isActive, or employeeId
    if (auth.role !== 'admin') {
      delete data.role;
      delete data.isActive;
      delete data.employeeId;
      delete data.department;
    }

    // Handle password update
    if (data.password) {
      const employee = await Employee.findById(id);
      if (employee) {
        employee.password = data.password;
        await employee.save();
        delete data.password;
      }
    }

    const employee = await Employee.findByIdAndUpdate(
      id,
      { $set: data },
      { new: true, runValidators: true }
    );

    if (!employee) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Employee not found' },
        { status: 404 }
      );
    }

    return NextResponse.json<ApiResponse<{ employee: Partial<EmployeeType> }>>(
      {
        success: true,
        data: {
          employee: {
            _id: employee._id.toString(),
            employeeId: employee.employeeId,
            name: employee.name,
            email: employee.email,
            department: employee.department,
            position: employee.position,
            avatar: employee.avatar,
            role: employee.role,
            isActive: employee.isActive,
          },
        },
        message: 'Employee updated successfully',
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Update employee error:', error);
    return NextResponse.json<ApiResponse>(
      { success: false, error: 'Failed to update employee' },
      { status: 500 }
    );
  }
}

// Delete employee (admin only - soft delete)
export async function DELETE(request: NextRequest, { params }: Params) {
  try {
    const auth = await getAuthFromCookies();

    if (!auth) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Not authenticated' },
        { status: 401 }
      );
    }

    if (auth.role !== 'admin') {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Access denied' },
        { status: 403 }
      );
    }

    const { id } = await params;

    await connectDB();

    // Soft delete - just set isActive to false
    const employee = await Employee.findByIdAndUpdate(
      id,
      { isActive: false },
      { new: true }
    );

    if (!employee) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Employee not found' },
        { status: 404 }
      );
    }

    return NextResponse.json<ApiResponse>(
      {
        success: true,
        message: 'Employee deactivated successfully',
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Delete employee error:', error);
    return NextResponse.json<ApiResponse>(
      { success: false, error: 'Failed to delete employee' },
      { status: 500 }
    );
  }
}
