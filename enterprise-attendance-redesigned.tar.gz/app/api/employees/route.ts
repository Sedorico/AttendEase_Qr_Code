import { NextRequest, NextResponse } from 'next/server';
import connectDB from '@/lib/db';
import Employee from '@/lib/models/Employee';
import { getAuthFromCookies } from '@/lib/auth';
import { ApiResponse, Employee as EmployeeType } from '@/types';

// Get all employees (admin only)
export async function GET(request: NextRequest) {
  try {
    const auth = await getAuthFromCookies();

    if (!auth) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Not authenticated' },
        { status: 401 }
      );
    }

    if (auth.role !== 'admin') {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Access denied' },
        { status: 403 }
      );
    }

    await connectDB();

    const { searchParams } = new URL(request.url);
    const department = searchParams.get('department');
    const search = searchParams.get('search');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');

    const query: Record<string, unknown> = {};

    if (department) {
      query.department = department;
    }

    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { employeeId: { $regex: search, $options: 'i' } },
      ];
    }

    const total = await Employee.countDocuments(query);
    const employees = await Employee.find(query)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit);

    return NextResponse.json<ApiResponse<{
      employees: Partial<EmployeeType>[];
      pagination: {
        total: number;
        page: number;
        limit: number;
        totalPages: number;
      };
    }>>(
      {
        success: true,
        data: {
          employees: employees.map(emp => ({
            _id: emp._id.toString(),
            employeeId: emp.employeeId,
            name: emp.name,
            email: emp.email,
            department: emp.department,
            position: emp.position,
            avatar: emp.avatar,
            role: emp.role,
            isActive: emp.isActive,
            createdAt: emp.createdAt.toISOString(),
          })),
          pagination: {
            total,
            page,
            limit,
            totalPages: Math.ceil(total / limit),
          },
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Get employees error:', error);
    return NextResponse.json<ApiResponse>(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// Create employee (admin only)
export async function POST(request: NextRequest) {
  try {
    const auth = await getAuthFromCookies();

    if (!auth) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Not authenticated' },
        { status: 401 }
      );
    }

    if (auth.role !== 'admin') {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Access denied' },
        { status: 403 }
      );
    }

    await connectDB();

    const data = await request.json();
    
    // Generate employee ID if not provided
    if (!data.employeeId) {
      const count = await Employee.countDocuments();
      data.employeeId = `EMP${String(count + 1).padStart(5, '0')}`;
    }

    const employee = await Employee.create(data);

    return NextResponse.json<ApiResponse<{ employee: Partial<EmployeeType> }>>(
      {
        success: true,
        data: {
          employee: {
            _id: employee._id.toString(),
            employeeId: employee.employeeId,
            name: employee.name,
            email: employee.email,
            department: employee.department,
            position: employee.position,
            role: employee.role,
            isActive: employee.isActive,
          },
        },
        message: 'Employee created successfully',
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Create employee error:', error);
    return NextResponse.json<ApiResponse>(
      { success: false, error: 'Failed to create employee' },
      { status: 500 }
    );
  }
}
