import { NextResponse } from 'next/server';
import connectDB from '@/lib/db';
import Attendance from '@/lib/models/Attendance';
import Employee from '@/lib/models/Employee';
import { getAuthFromCookies } from '@/lib/auth';
import { ApiResponse } from '@/types';

export async function GET() {
  try {
    const auth = await getAuthFromCookies();

    if (!auth) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Not authenticated' },
        { status: 401 }
      );
    }

    await connectDB();

    const employee = await Employee.findOne({ employeeId: auth.employeeId });
    
    if (!employee) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Employee not found' },
        { status: 404 }
      );
    }

    // Get today's records
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const records = await Attendance.find({
      employeeId: employee._id,
      timestamp: { $gte: today, $lt: tomorrow },
    }).sort({ timestamp: 1 });

    const timeIn = records.find(r => r.type === 'TIME_IN');
    const timeOut = records.find(r => r.type === 'TIME_OUT');

    return NextResponse.json<ApiResponse>(
      {
        success: true,
        data: {
          timeIn: timeIn ? {
            timestamp: timeIn.timestamp.toISOString(),
            _id: timeIn._id.toString(),
          } : null,
          timeOut: timeOut ? {
            timestamp: timeOut.timestamp.toISOString(),
            _id: timeOut._id.toString(),
          } : null,
          hasTimeIn: !!timeIn,
          hasTimeOut: !!timeOut,
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Get today attendance error:', error);
    return NextResponse.json<ApiResponse>(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}
