import { NextRequest, NextResponse } from 'next/server';
import connectDB from '@/lib/db';
import { parseQRToken, validateQRToken, checkAndMarkTokenUsed } from '@/lib/qr';
import Employee from '@/lib/models/Employee';
import Attendance from '@/lib/models/Attendance';
import QRSession from '@/lib/models/QRSession';
import { ApiResponse, AttendanceType } from '@/types';
import { WORK_START_HOUR, WORK_START_MINUTE, LATE_THRESHOLD_MINUTES } from '@/lib/constants';

export async function POST(request: NextRequest) {
  try {
    const { qrData, deviceInfo } = await request.json();

    if (!qrData) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'QR data is required' },
        { status: 400 }
      );
    }

    // Parse QR token
    const tokenData = parseQRToken(qrData);
    
    if (!tokenData) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Invalid QR code format' },
        { status: 400 }
      );
    }

    // Validate token
    const validation = validateQRToken(tokenData);
    
    if (!validation.valid) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: validation.error },
        { status: 400 }
      );
    }

    // Check for replay attack
    if (!checkAndMarkTokenUsed(tokenData)) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'QR code has already been used' },
        { status: 400 }
      );
    }

    await connectDB();

    // Find employee
    const employee = await Employee.findOne({ 
      employeeId: tokenData.employeeId,
      isActive: true 
    });

    if (!employee) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Employee not found or inactive' },
        { status: 404 }
      );
    }

    // Invalidate the QR session
    await QRSession.updateOne(
      { token: tokenData.nonce },
      { used: true, usedAt: new Date() }
    );

    // Get today's attendance records
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const todayRecords = await Attendance.find({
      employeeId: employee._id,
      timestamp: { $gte: today, $lt: tomorrow },
    }).sort({ timestamp: 1 });

    // Determine attendance type
    let type: AttendanceType;
    const hasTimeIn = todayRecords.some(r => r.type === 'TIME_IN');
    const hasTimeOut = todayRecords.some(r => r.type === 'TIME_OUT');

    if (!hasTimeIn) {
      type = 'TIME_IN';
    } else if (!hasTimeOut) {
      type = 'TIME_OUT';
    } else {
      return NextResponse.json<ApiResponse>(
        { 
          success: false, 
          error: 'You have already completed your attendance for today' 
        },
        { status: 400 }
      );
    }

    // Check for duplicate scans within cooldown period
    const lastRecord = todayRecords[todayRecords.length - 1];
    if (lastRecord) {
      const timeSinceLastScan = Date.now() - new Date(lastRecord.timestamp).getTime();
      if (timeSinceLastScan < 10000) { // 10 seconds cooldown
        return NextResponse.json<ApiResponse>(
          { success: false, error: 'Please wait before scanning again' },
          { status: 429 }
        );
      }
    }

    // Create attendance record
    const now = new Date();
    const attendance = await Attendance.create({
      employeeId: employee._id,
      type,
      timestamp: now,
      deviceInfo: deviceInfo || 'Scanner Kiosk',
      qrTokenUsed: tokenData.nonce,
    });

    // Determine if late (for TIME_IN)
    let isLate = false;
    if (type === 'TIME_IN') {
      const timeInHour = now.getHours();
      const timeInMinute = now.getMinutes();
      const lateTime = WORK_START_HOUR * 60 + WORK_START_MINUTE + LATE_THRESHOLD_MINUTES;
      const currentTime = timeInHour * 60 + timeInMinute;
      isLate = currentTime > lateTime;
    }

    return NextResponse.json<ApiResponse<{
      attendance: typeof attendance;
      employee: {
        _id: string;
        name: string;
        employeeId: string;
        department: string;
        position: string;
        avatar?: string;
      };
      type: AttendanceType;
      timestamp: string;
      isLate: boolean;
    }>>(
      {
        success: true,
        data: {
          attendance,
          employee: {
            _id: employee._id.toString(),
            name: employee.name,
            employeeId: employee.employeeId,
            department: employee.department,
            position: employee.position,
            avatar: employee.avatar,
          },
          type,
          timestamp: now.toISOString(),
          isLate,
        },
        message: `${type === 'TIME_IN' ? 'Time In' : 'Time Out'} recorded successfully${isLate ? ' (Late)' : ''}`,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('QR validation error:', error);
    return NextResponse.json<ApiResponse>(
      { success: false, error: 'Failed to process QR code' },
      { status: 500 }
    );
  }
}
