// Employee Types
export interface Employee {
  _id: string;
  employeeId: string;
  name: string;
  email: string;
  department: string;
  position: string;
  avatar?: string;
  role: 'employee' | 'admin';
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface EmployeeWithPassword extends Employee {
  password: string;
}

// Attendance Types
export type AttendanceType = 'TIME_IN' | 'TIME_OUT';

export interface Attendance {
  _id: string;
  employeeId: string;
  employee?: Employee;
  type: AttendanceType;
  timestamp: string;
  deviceInfo?: string;
  qrTokenUsed: string;
  location?: string;
  notes?: string;
}

export interface AttendanceRecord {
  date: string;
  timeIn?: string;
  timeOut?: string;
  duration?: string;
  status: 'present' | 'late' | 'absent' | 'half-day';
}

// QR Session Types
export interface QRSession {
  _id: string;
  employeeId: string;
  token: string;
  expiresAt: string;
  createdAt: string;
}

// Auth Types
export interface AuthPayload {
  userId: string;
  employeeId: string;
  role: 'employee' | 'admin';
  email: string;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterData extends LoginCredentials {
  name: string;
  employeeId: string;
  department: string;
  position: string;
}

// QR Token Payload
export interface QRTokenPayload {
  employeeId: string;
  timestamp: number;
  expiresAt: number;
  signature: string;
}

// API Response Types
export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

// Socket Event Types
export interface ScanEvent {
  employeeId: string;
  employeeName: string;
  type: AttendanceType;
  timestamp: string;
  success: boolean;
}

export interface NotificationEvent {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  message: string;
  timestamp: string;
}

// Dashboard Stats Types
export interface DashboardStats {
  totalEmployees: number;
  presentToday: number;
  lateToday: number;
  absentToday: number;
  onLeave: number;
}

export interface AttendanceChartData {
  date: string;
  present: number;
  late: number;
  absent: number;
}

// Filter Types
export interface AttendanceFilters {
  startDate?: string;
  endDate?: string;
  employeeId?: string;
  department?: string;
  type?: AttendanceType;
}

// Notification Types
export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'success' | 'error' | 'info' | 'warning';
  read: boolean;
  timestamp: string;
}
